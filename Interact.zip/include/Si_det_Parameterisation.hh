#ifndef Si_det_Parameterisation_HH
#define Si_det_Parameterisation_HH 1

#include "globals.hh"
#include "G4SystemOfUnits.hh"
#include "G4Box.hh"
#include "G4VPVParameterisation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4Material.hh"

// Dummy declarations to get rid of warnings ...
class G4Trd;
class G4Trap;
class G4Cons;
class G4Orb;
class G4Sphere;
class G4Torus;
class G4Para;
class G4Hype;
class G4Tubs;
class G4Polycone;
class G4Polyhedra;
class G4Ellipsoid;

class Si_det_Parameterisation : public G4VPVParameterisation
{
 public:
  Si_det_Parameterisation();
  virtual ~Si_det_Parameterisation();
  void ComputeTransformation (const G4int copyNo, G4VPhysicalVolume* physVol) const;
  void ComputeDimensions (G4Box& Si_det_box, const G4int copyNo, const G4VPhysicalVolume* physVol) const;

  private:  // Dummy declarations to get rid of warnings ...

    void ComputeDimensions (G4Trd&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Trap&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Cons&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Sphere&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Orb&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Torus&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Para&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Hype&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Tubs&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Polycone&,const G4int,const G4VPhysicalVolume*) const { };
    void ComputeDimensions (G4Polyhedra&,const G4int,const G4VPhysicalVolume*) const { }; 
    void ComputeDimensions (G4Ellipsoid&,const G4int,const G4VPhysicalVolume*) const { }; 
};

#endif
