﻿#include "DetectorConstruction.hh"

DetectorConstruction::DetectorConstruction()
{}

DetectorConstruction::~DetectorConstruction()
{}

G4VPhysicalVolume *DetectorConstruction::Construct()
{
  G4NistManager *nist = G4NistManager::Instance();

  //--------------------------------------- World --------------------------------------------------

  G4double world_sizeXY = 1.*m;
  G4double world_sizeZ  = 1.*m;
  G4Box *world_solid = new G4Box("world_solid", world_sizeXY/2., world_sizeXY/2., world_sizeZ/2.);

  G4Material *world_mat = nist->FindOrBuildMaterial("G4_N");
  G4LogicalVolume *world_log = new G4LogicalVolume(world_solid, world_mat, "world_log");

  G4VPhysicalVolume *world_phys =
    new G4PVPlacement(0,                  // no rotation
                      G4ThreeVector(),    // position
                      world_log,          // logical volume
                      "world_phys",       // name
                      0,                  // mother volume
                      false,              // no boolean operation
                      0);                 // copy number

  //---------------------------------------- Box ---------------------------------------------------

  G4double box_sizeXY = 0.9*m;
  G4double box_sizeZ  = 5.*cm;
  G4Box *box_solid = new G4Box("box_solid", box_sizeXY/2., box_sizeXY/2., box_sizeZ/2.);

  G4Material *box_mat = nist->FindOrBuildMaterial("G4_Pb");
  G4LogicalVolume *box_log = new G4LogicalVolume(box_solid, box_mat, "box_log");

  G4VPhysicalVolume *box_phys =
    new G4PVPlacement(0,                  // no rotation
                      G4ThreeVector(),    // position
                      box_log,            // logical volume
                      "box_phys",         // name
                      world_log,          // mother volume
                      false,              // no boolean operation
                      0);                 // copy number

  //--------------------------------------- Return -------------------------------------------------

  return world_phys;
}
